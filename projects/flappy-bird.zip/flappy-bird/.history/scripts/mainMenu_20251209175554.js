class mainMenu extends Phaser.Scene {
    constructor() {
        super({ key: 'mainMenu' });
    }
    preload() {
        this.load
    }
}
const config = {
    type 
}
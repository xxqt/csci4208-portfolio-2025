// class WorldScene extends Phaser.Scene {
//     constructor() {
//         super({ key: 'worldscene' });

//         this.score = 0;
//         this.gameOver = false;
//         this.pipeSpeed = -200;
//         this.backgroundSpeed = 1;
//         this.groundSpeed = 2;
//     }

//     preload() {
//         // numbers
//         this.load.image('0', 'sprites/0.png');
//         this.load.image('1', 'sprites/1.png');
//         this.load.image('2', 'sprites/2.png');
//         this.load.image('3', 'sprites/3.png');
//         this.load.image('4', 'sprites/4.png');
//         this.load.image('5', 'sprites/5.png');
//         this.load.image('6', 'sprites/6.png');
//         this.load.image('7', 'sprites/7.png');
//         this.load.image('8', 'sprites/8.png');
//         this.load.image('9', 'sprites/9.png');

//         // backgrounds
//         this.load.image('background-day', 'sprites/background-day.png');
//         this.load.image('background-night', 'sprites/background-night.png');

//         // pipes
//         // this pipe is facing bottom up
//         // must flip it to face top down
//         this.load.image('pipe-green', 'sprites/pipe-green.png');

//         //ground
//         this.load.image('ground', 'sprites/base.png');

//         // flappy bird
//         this.load.image('yellowbird-upflap', 'sprites/yellowbird-upflap.png');
//         this.load.image('yellowbird-midflap', 'sprites/yellowbird-midflap.png');
//         this.load.image('yellowbird-downflap', 'sprites/yellowbird-downflap.png');



//     }

//     create() {

//         this.input.keyboard.enabled = true;

//         this.createFlappyAnimations();

//     }

//     createFlappyAnimations() {
//         this.anims.create({
//             key: 'fly',
//             frames: [{ key: 'yellowbird-upflap' }, { key: 'yellowbird-midflap' }, { key: 'yellowbird-downflap' }],
//             frameRate: 10,
//             repeat: -1 // loop forever
//         });
//     }

//     movingBackground() {
//         // moving background logic
//         this.background = this.add.tileSprite(
//             0,
//             0,
//             this.game.config.width * 2,
//             this.game.config.height,
//             'background-day'
//         );
//         this.background.setOrigin(0, 0);
//         this.background.setScrollFactor(0);

//     }

//     spawnPipes() {
//         // spawn pipes logic
//         if (this.gameOver) return;

//         // ranging gaps
//         const gapY = Phaser.Math.Between(
//             this.game.config.height * 0.2,
//             this.game.config.height * 0.7
//         );
//         const gapSize = Phaser.Math.Between(120, 150);

//         // top pipe
//         const topPipe = this.physics.add.sprite(
//             this.game.config.width,
//             gapY - gapSize / 2,
//             'pipe-green'
//         );
//         topPipe.setOrigin(0, 1); // set origin to bottom left
//         topPipe.body.allowGravity = false;
//         topPipe.setVelocityX(-200); // move left
//         bottomPipe.setImmovable(true);

//         // bottom pipe
//         const bottomPipe = this.physics.add.sprite(
//             this.game.config.width,
//             gapY + gapSize / 2,
//             'pipe-green'
//         );
//         bottomPipe.setOrigin(0, 0);
//         bottomPipe.body.allowGravity = false;
//         bottomPipe.setVelocityX(this.pipeSpeed); // move left
//         bottomPipe.setImmovable(true);

 
//     }

//     flap() {
//         // flap logic
//         if (this.gameOver){
//             this.restartGame();
//             return;
//         }
//     }

//     pipeCollision() {
//         // pipe collision logic
//         if (!this.gameOver) {
//             this.gameOver = true;
//             this.physics.pause();
//             this.mario.setTint(0xff0000);
//         }
//     }

//     isGameOver() {
//         this.gameOver = true;

//         this
//     }

//     pauseGame() {
//         // pause game logic
//     }

//     update() {
//         // update logic
//         this.mario.nearL
//     }
// }

// World Scene (Game)
class WorldScene extends Phaser.Scene {
    constructor() {
        super({ key: 'worldscene' });

        this.score = 0;
        this.gameOver = false;
        this.pipeSpeed = -200;
        this.backgroundSpeed = 1;
        this.groundSpeed = 2;
    }

    preload() {
        // numbers
        this.load.image('0', 'sprites/0.png');
        this.load.image('1', 'sprites/1.png');
        this.load.image('2', 'sprites/2.png');
        this.load.image('3', 'sprites/3.png');
        this.load.image('4', 'sprites/4.png');
        this.load.image('5', 'sprites/5.png');
        this.load.image('6', 'sprites/6.png');
        this.load.image('7', 'sprites/7.png');
        this.load.image('8', 'sprites/8.png');
        this.load.image('9', 'sprites/9.png');

        // backgrounds
        this.load.image('background-day', 'sprites/background-day.png');
        this.load.image('background-night', 'sprites/background-night.png');

        // pipes
        this.load.image('pipe-green', 'sprites/pipe-green.png');

        // ground
        this.load.image('ground', 'sprites/base.png');

        // flappy bird
        this.load.image('yellowbird-upflap', 'sprites/yellowbird-upflap.png');
        this.load.image('yellowbird-midflap', 'sprites/yellowbird-midflap.png');
        this.load.image('yellowbird-downflap', 'sprites/yellowbird-downflap.png');
    }

    create() {
        this.input.keyboard.enabled = true;

        // Create background
        this.movingBackground();

        // Create bird
        this.bird = this.physics.add.sprite(100, this.game.config.height / 2, 'yellowbird-midflap');
        this.bird.setCollideWorldBounds(false);
        this.bird.body.setGravityY(1000);
        this.bird.setScale(2);

        // Create ground
        this.createGround();

        // Create pipes group
        this.pipes = this.physics.add.group();

        // Create animations
        this.createFlappyAnimations();
        this.bird.play('fly');

        // Controls
        this.input.on('pointerdown', this.flap, this);
        this.input.keyboard.on('keydown-SPACE', this.flap, this);

        // Start spawning pipes
        this.pipeTimer = this.time.addEvent({
            delay: 1800,
            callback: this.spawnPipes,
            callbackScope: this,
            loop: true
        });

        // Score text
        this.scoreText = this.add.text(16, 16, '0', {
            fontSize: '32px',
            fill: '#fff',
            fontFamily: 'Arial',
            stroke: '#000',
            strokeThickness: 4
        });

        // Collisions
        this.physics.add.overlap(this.bird, this.pipes, this.pipeCollision, null, this);
        this.physics.add.collider(this.bird, this.ground, this.groundCollision, null, this);
    }

    createFlappyAnimations() {
        this.anims.create({
            key: 'fly',
            frames: [
                { key: 'yellowbird-upflap' }, 
                { key: 'yellowbird-midflap' }, 
                { key: 'yellowbird-downflap' }
            ],
            frameRate: 10,
            repeat: -1
        });
    }

    movingBackground() {
        this.background = this.add.tileSprite(
            0,
            0,
            this.game.config.width * 2,
            this.game.config.height,
            'background-day'
        );
        this.background.setOrigin(0, 0);
        this.background.setScrollFactor(0);
    }

    createGround() {
        const groundY = this.game.config.height - 56;
        
        this.ground = this.add.tileSprite(
            0,
            groundY,
            this.game.config.width * 2,
            112,
            'ground'
        );
        this.ground.setOrigin(0, 0);
        
        this.physics.add.existing(this.ground, true);
        this.ground.body.setSize(this.game.config.width * 2, 112);
    }

    spawnPipes() {
        if (this.gameOver) return;

        const groundHeight = 112;
        const minGapY = 100;
        const maxGapY = this.game.config.height - groundHeight - 150;
        const gapY = Phaser.Math.Between(minGapY, maxGapY);
        const gapSize = Phaser.Math.Between(120, 150);

        // Top pipe
        const topPipe = this.pipes.create(
            this.game.config.width,
            gapY - gapSize / 2,
            'pipe-green'
        );
        topPipe.setOrigin(0.5, 1);
        topPipe.setFlipY(true);
        topPipe.body.allowGravity = false;
        topPipe.body.setVelocityX(this.pipeSpeed);
        topPipe.setImmovable(true);
        topPipe.scored = false;
        topPipe.isTopPipe = true;

        // Bottom pipe
        const bottomPipe = this.pipes.create(
            this.game.config.width,
            gapY + gapSize / 2,
            'pipe-green'
        );
        bottomPipe.setOrigin(0.5, 0);
        bottomPipe.body.allowGravity = false;
        bottomPipe.body.setVelocityX(this.pipeSpeed);
        bottomPipe.setImmovable(true);
        bottomPipe.scored = false;
    }

    flap() {
        if (this.gameOver) {
            this.restartGame();
            return;
        }

        this.bird.setVelocityY(-400);
        
        this.tweens.add({
            targets: this.bird,
            angle: -20,
            duration: 100
        });
    }

    pipeCollision() {
        if (!this.gameOver) {
            this.isGameOver();
        }
    }

    groundCollision() {
        if (!this.gameOver) {
            this.isGameOver();
        }
    }

    isGameOver() {
        this.gameOver = true;

        this.bird.anims.stop();
        this.bird.setTint(0xff0000);

        this.physics.pause();

        if (this.pipeTimer) {
            this.pipeTimer.destroy();
        }

        this.add.text(
            this.game.config.width / 2,
            this.game.config.height / 2 - 50,
            'Game Over!',
            {
                fontSize: '64px',
                fill: '#fff',
                fontFamily: 'Arial',
                stroke: '#000',
                strokeThickness: 8
            }
        ).setOrigin(0.5);

        this.add.text(
            this.game.config.width / 2,
            this.game.config.height / 2 + 30,
            `Score: ${this.score}`,
            {
                fontSize: '36px',
                fill: '#fff',
                fontFamily: 'Arial',
                stroke: '#000',
                strokeThickness: 6
            }
        ).setOrigin(0.5);

        this.add.text(
            this.game.config.width / 2,
            this.game.config.height / 2 + 80,
            'Click or Press SPACE to Restart',
            {
                fontSize: '24px',
                fill: '#fff',
                fontFamily: 'Arial',
                stroke: '#000',
                strokeThickness: 4
            }
        ).setOrigin(0.5);
    }

    pauseGame() {
        if (!this.gameOver) {
            this.physics.pause();
            this.bird.anims.pause();
            if (this.pipeTimer) {
                this.pipeTimer.paused = true;
            }
        }
    }

    resumeGame() {
        if (!this.gameOver) {
            this.physics.resume();
            this.bird.anims.resume();
            if (this.pipeTimer) {
                this.pipeTimer.paused = false;
            }
        }
    }

    restartGame() {
        this.scene.restart();
        this.score = 0;
        this.gameOver = false;
    }

    update() {
        if (this.gameOver) return;

        this.background.tilePositionX += this.backgroundSpeed;
        this.ground.tilePositionX += this.groundSpeed;

        if (this.bird.body.velocity.y > 0) {
            if (this.bird.angle < 90) {
                this.bird.angle += 3;
            }
        }

        if (this.bird.y < 0) {
            this.isGameOver();
        }

        this.pipes.children.entries.forEach(pipe => {
            if (pipe.x < -100) {
                pipe.destroy();
            }

            if (pipe.isTopPipe && !pipe.scored && pipe.x + pipe.width / 2 < this.bird.x) {
                this.score++;
                this.scoreText.setText(this.score.toString());
                pipe.scored = true;
            }
        });
    }
}
class WorldScene extends Phaser.Scene {
    constructor() {
        super({ key: 'worldscene' });
    }

    preload() {
        // numbers
        this.load.image('0', 'sprites/0.png');
        this.load.image('1', 'sprites/1.png');
        this.load.image('2', 'sprites/2.png');
        this.load.image('3', 'sprites/3.png');
        this.load.image('4', 'sprites/4.png');
        this.load.image('5', 'sprites/5.png');
        this.load.image('6', 'sprites/6.png');
        this.load.image('7', 'sprites/7.png');
        this.load.image('8', 'sprites/8.png');
        this.load.image('9', 'sprites/9.png');

        // backgrounds

    }

    create() {

    }

    update() {

    }
}

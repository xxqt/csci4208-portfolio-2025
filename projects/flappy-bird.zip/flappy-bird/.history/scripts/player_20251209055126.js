class Player extends Phaser.arcade.Sprite {


    preload() {
}
class Player extends Phaser.arcade.Sprite {


    preload() {
        this.load
    }
}
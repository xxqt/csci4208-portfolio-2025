class WorldScene extends Phaser.Scene {
    constructor() {
        super({ key: 'worldscene' });
    }

    preload() {
        // numbers
        this.load.image('0', 'assets/numbers/0.png');
        this.load.image('1', 'assets/numbers/1.png');
        this.load.image('2', 'assets/numbers/2.png');
        this.load.image('3', 'assets/numbers/3.png');
        this.load.image('4', 'assets/numbers/4.png');
        this.load.image('5', 'assets/numbers/5.png');
        this.load.image('6', 'assets/numbers/6.png');
        this.load.image('7', 'assets/numbers/7.png');
        this.load.image('8', 'assets/numbers/8.png');
        this.load.image('9', 'assets/numbers/9.png');
    }

    create() {

    }

    update() {

    }
}

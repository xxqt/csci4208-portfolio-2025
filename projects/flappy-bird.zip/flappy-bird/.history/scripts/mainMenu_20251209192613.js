class mainMenu extends Phaser.Scene {
    constructor() {
        super({ key: 'mainMenu' });
    }
    preload() {
        this.load.image('menu-bg', 'sprites/message.png');
        this.load.image('background', 'sprites/background-day.png');
        this.load.image('ground', 'sprites/ground.png');

    }
    create() {
        // this.add.image(288, 512, 'background');
        // this.add.image(184, 267, 'menu-bg');

        createBackground

        this.spaceKey = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.SPACE);
    }

    createBackground() {
        // tileSprite allows us to create a repeating, scrollable texture
        // Parameters: (x, y, width, height, texture key)
        this.background = this.add.tileSprite(
            0,                              // x position (top-left corner)
            0,                              // y position (top-left corner)
            this.game.config.width * 2,     // width (make it 2x screen width for seamless scrolling)
            this.game.config.height,        // height (full screen height)
            'background-day'                // texture to use
        );

        // Set origin to top-left corner
        this.background.setOrigin(0, 0);

        // Prevent camera from moving this object
        this.background.setScrollFactor(0);
    }

    createGround() {
        // Position ground at the bottom of the screen
        const groundY = this.game.config.height - 56;  // 56 pixels from bottom

        // Create scrolling ground
        this.ground = this.add.tileSprite(
            0,                              // x position
            groundY,                        // y position (near bottom)
            this.game.config.width * 2,     // width
            112,                            // height of ground sprite
            'ground'                        // texture
        );

        // Set origin to top-left
        this.ground.setOrigin(0, 0);
    }

    update() {
        if (this.spaceKey.isDown) {
            this.scene.start('worldScene');
        }
    }
}

window.mainMenu = mainMenu;

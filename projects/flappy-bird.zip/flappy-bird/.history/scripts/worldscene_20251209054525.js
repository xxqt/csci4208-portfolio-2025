class WorldScene extends Phaser.Scene {
    constructor() {
        super({ key: 'worldscene' });
    }

    preload() {
        // number
    }

    create() {

    }

    update() {

    }
}

// class mainMenu extends Phaser.Scene {
//     constructor() {
//         super({ key: 'mainMenu' });
//     }
//     preload() {
//         this.load.image('menu-bg', 'sprites/message.png');
//         this.load.image('background', 'sprites/background-day.png');    
//         this.load.image('ground', 'sprites/ground.png');

//     }
//     create() {
//         this.add.image(288, 512, 'background');
//         this.add.image(184, 267, 'menu-bg');

//         this.spaceKey = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.SPACE);
//     }

//     update() {
//         if (this.spaceKey.isDown) {
//             this.scene.start('worldScene');
//         }
//     }
// }


// Main Menu Scene
class MainMenu extends Phaser.Scene {
    constructor() {
        super({ key: 'MainMenu' });
    }

    preload() {
        // Load main menu assets
        this.load.image('menu-bg', 'sprites/message.png');
        this.load.image('background-day', 'sprites/background-day.png');
        this.load.image('ground', 'sprites/base.png');

        // Preload bird sprites for menu animation
        this.load.image('yellowbird-midflap', 'sprites/yellowbird-midflap.png');
    }

    create() {
        // Add background (scaled to fit)
        this.background = this.add.image(
            this.game.config.width / 2, 
            this.game.config.height / 2, 
            'background-day'
        );

        // Scale background to cover screen
        const scaleX = this.game.config.width / this.background.width;
        const scaleY = this.game.config.height / this.background.height;
        const scale = Math.max(scaleX, scaleY);
        this.background.setScale(scale);

        // Add ground at bottom
        const groundY = this.game.config.height - 56;
        this.ground = this.add.tileSprite(
            this.game.config.width / 2,
            groundY,
            this.game.config.width,
            112,
            'ground'
        );

        // Add menu message/logo in center
        this.menuBg = this.add.image(
            this.game.config.width / 2,
            this.game.config.height / 2 - 50,
            'menu-bg'
        );

        // Add instructions
        this.add.text(
            this.game.config.width / 2,
            this.game.config.height - 150,
            'Press SPACE or Click to Start',
            {
                fontSize: '24px',
                fill: '#fff',
                fontFamily: 'Arial',
                stroke: '#000',
                strokeThickness: 4
            }
        ).setOrigin(0.5);

        // Input handlers
        this.spaceKey = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.SPACE);
        this.input.on('pointerdown', this.startGame, this);

        // Animate ground
        this.groundSpeed = 2;
    }

    startGame() {
        this.scene.start('WorldScene');
    }

    update() {
        // Scroll ground for visual effect
        this.ground.tilePositionX += this.groundSpeed;

        // Start game on space press
        if (Phaser.Input.Keyboard.JustDown(this.spaceKey)) {
            this.startGame();
        }
    }
}
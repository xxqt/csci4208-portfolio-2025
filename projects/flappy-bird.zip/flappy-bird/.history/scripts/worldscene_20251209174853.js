class WorldScene extends Phaser.Scene {
    constructor() {
        super({ key: 'worldscene' });

        this.score = 0;
        this.gameOver = false;
        this.pipeSpeed = -200;
    }

    preload() {
        // numbers
        this.load.image('0', 'sprites/0.png');
        this.load.image('1', 'sprites/1.png');
        this.load.image('2', 'sprites/2.png');
        this.load.image('3', 'sprites/3.png');
        this.load.image('4', 'sprites/4.png');
        this.load.image('5', 'sprites/5.png');
        this.load.image('6', 'sprites/6.png');
        this.load.image('7', 'sprites/7.png');
        this.load.image('8', 'sprites/8.png');
        this.load.image('9', 'sprites/9.png');

        // backgrounds
        this.load.image('background-day', 'sprites/background-day.png');
        this.load.image('background-night', 'sprites/background-night.png');

        // pipes
        // this pipe is facing bottom up
        // must flip it to face top down
        this.load.image('pipe-green', 'sprites/pipe-green.png');

        // flappy bird
        this.load.image('yellowbird-upflap', 'sprites/yellowbird-upflap.png');
        this.load.image('yellowbird-midflap', 'sprites/yellowbird-midflap.png');
        this.load.image('yellowbird-downflap', 'sprites/yellowbird-downflap.png');



    }

    create() {

        this.input.keyboard.enabled = true;

        this.createFlappyAnimations();

    }

    createFlappyAnimations() {
        this.anims.create({
            key: 'fly',
            frames: [{ key: 'yellowbird-upflap' }, { key: 'yellowbird-midflap' }, { key: 'yellowbird-downflap' }],
            frameRate: 10,
            repeat: -1 // loop forever
        });
    }

    movingBackground() {
        // moving background logic
        this.background = this.add.tileSprite(
            0,
            0,
            this.game.config.width * 2,
            this.game.config.height,
            'background-day'
        );
        this.background.setOrigin(0, 0);
        this.background.setScrollFactor(0);

    }

    spawnPipes() {
        // spawn pipes logic
        if (this.gameOver) return;

        // ranging gaps
        const gapY = Phaser.Math.Between(
            this.game.config.height * 0.2,
            this.game.config.height * 0.7
        );
        const gapSize = Phaser.Math.Between(120, 150);

        // top pipe
        const topPipe = this.physics.add.sprite(
            this.game.config.width,
            gapY - gapSize / 2,
            'pipe-green'
        );
        topPipe.setOrigin(0, 1); // set origin to bottom left
        topPipe.body.allowGravity = false;
        topPipe.setVelocityX(-200); // move left

        // bottom pipe
        const bottomPipe = this.physics.add.sprite(
            this.game.config.width,
            gapY + gapSize / 2,
            'pipe-green'
        );
        bottomPipe.setOrigin(0, 0);
        bottomPipe.body.allowGravity = false;
        bottomPipe.setVelocityX(this.pipeSpeed); // move left
        

    }

    isGameOver() {
        
    }

    pauseGame() {
        // pause game logic
    }

    update() {
        // update logic
        this.mario.nearL
    }
}

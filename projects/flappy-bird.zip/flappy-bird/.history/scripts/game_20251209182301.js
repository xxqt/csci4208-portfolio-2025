const config = {
    type  Phaser.AUTO,
    width: 288,
    height: 512,
    physics: {
        default: 'arcade',
        arcade: {
            gravity: { y: 300 },
            debug: false
        }
    },
    scene: [mainMenu, WorldScene]
};

const game = new Phaser.Game(config);

window.game = game;
class mainMenu extends Phaser.Scene {
    constructor() {
        super({ key: 'mainMenu' });
    }
    preload() {
        this.load.image('menu-bg', 'sprites/message.png');
        this.load.image('background-day', 'sprites/background-day.png');
        this.load.image('ground', 'sprites/base.png');

        this.backgroundSpeed = 1;
        this.groundSpeed = 2;
    }
    create() {
        // this.add.image(288, 512, 'background');


        this.createBackground();
        this.createGround();

        const centerX = this.cameras.main.width / 2;
        const centerY = this.cameras.main.height / 2;

        this.menuImage = this.add.image(centerX, centerY, 'menu-bg');
        this.menuImage.setOrigin(0.5, 0.5);

        this.click = this.input.keyboard.addKey(Phaser.Input.Keyboard.justDown());
    }

    createBackground() {
        // tileSprite allows us to create a repeating, scrollable texture
        // Parameters: (x, y, width, height, texture key)
        this.background = this.add.tileSprite(
            0,                              // x position (top-left corner)
            0,                              // y position (top-left corner)
            this.game.config.width * 2,     // width (make it 2x screen width for seamless scrolling)
            this.game.config.height,        // height (full screen height)
            'background-day'                // texture to use
        );

        // Set origin to top-left corner
        this.background.setOrigin(0, 0);

        // Prevent camera from moving this object
        this.background.setScrollFactor(0);
    }

    createGround() {
        // Position ground at the bottom of the screen
        const groundY = this.game.config.height - 56;  // 56 pixels from bottom

        // Create scrolling ground
        this.ground = this.add.tileSprite(
            0,                              // x position
            groundY,                        // y position (near bottom)
            this.game.config.width * 2,     // width
            112,                            // height of ground sprite
            'ground'                        // texture
        );

        // Set origin to top-left
        this.ground.setOrigin(0, 0);
    }

    update() {


        if (this.click.isDown) {
            this.scene.start('worldScene');
        }

        this.background.tilePositionX += this.backgroundSpeed;
        this.ground.tilePositionX += this.groundSpeed;
    }
}

window.mainMenu = mainMenu;

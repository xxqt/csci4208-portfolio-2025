

class WorldScene extends Phaser.Scene {
    constructor() {
        super({ key: 'worldcene' });

        this.score = 0;
        this.gameOver = false;
        this.pipeSpeed = -200;
        this.backgroundSpeed = 1;
        this.groundSpeed = 2;
    }

    preload() {
        // numbers
        this.load.image('0', 'sprites/0.png');
        this.load.image('1', 'sprites/1.png');
        this.load.image('2', 'sprites/2.png');
        this.load.image('3', 'sprites/3.png');
        this.load.image('4', 'sprites/4.png');
        this.load.image('5', 'sprites/5.png');
        this.load.image('6', 'sprites/6.png');
        this.load.image('7', 'sprites/7.png');
        this.load.image('8', 'sprites/8.png');
        this.load.image('9', 'sprites/9.png');

        // backgrounds
        this.load.image('background-day', 'sprites/background-day.png');
        this.load.image('background-night', 'sprites/background-night.png');

        // pipes
        this.load.image('pipe-green', 'sprites/pipe-green.png');

        // ground
        this.load.image('ground', 'sprites/base.png');

        // flappy bird
        this.load.image('yellowbird-upflap', 'sprites/yellowbird-upflap.png');
        this.load.image('yellowbird-midflap', 'sprites/yellowbird-midflap.png');
        this.load.image('yellowbird-downflap', 'sprites/yellowbird-downflap.png');
    }

    create() {
        this.input.keyboard.enabled = true;

        // Create background
        this.movingBackground();

        // Create ground
        this.createGround();

        // Create player using Player class
        this.player = new Player(this, 100, this.game.config.height / 2);

        // Create pipes group
        this.pipes = this.physics.add.group();

        // Controls
        this.input.on('pointerdown', () => this.player.flap(), this);
        this.input.keyboard.on('keydown-SPACE', () => this.player.flap(), this);

        // Start spawning pipes
        this.pipeTimer = this.time.addEvent({
            delay: 1800,
            callback: this.spawnPipes,
            callbackScope: this,
            loop: true
        });

        // Score text
        this.scoreText = this.add.text(16, 16, '0', {
            fontSize: '32px',
            fill: '#fff',
            fontFamily: 'Arial',
            stroke: '#000',
            strokeThickness: 4
        });

        // Collisions - use player.getSprite() to get the physics sprite
        this.physics.add.overlap(this.player.getSprite(), this.pipes, this.pipeCollision, null, this);
        this.physics.add.collider(this.player.getSprite(), this.ground, this.groundCollision, null, this);
    }

    movingBackground() {
        this.background = this.add.tileSprite(
            0,
            0,
            this.game.config.width * 2,
            this.game.config.height,
            'background-day'
        );
        this.background.setOrigin(0, 0);
        this.background.setScrollFactor(0);
    }

    createGround() {
        const groundY = this.game.config.height - 56;
        
        this.ground = this.add.tileSprite(
            0,
            groundY,
            this.game.config.width * 2,
            112,
            'ground'
        );
        this.ground.setOrigin(0, 0);
        
        this.physics.add.existing(this.ground, true);
        this.ground.body.setSize(this.game.config.width * 2, 112);
    }

    spawnPipes() {
        if (this.gameOver) return;

        const groundHeight = 112;
        const minGapY = 100;
        const maxGapY = this.game.config.height - groundHeight - 150;
        const gapY = Phaser.Math.Between(minGapY, maxGapY);
        const gapSize = Phaser.Math.Between(120, 150);

        // Top pipe
        const topPipe = this.pipes.create(
            this.game.config.width,
            gapY - gapSize / 2,
            'pipe-green'
        );
        topPipe.setOrigin(0.5, 1);
        topPipe.setFlipY(true);
        topPipe.body.allowGravity = false;
        topPipe.body.setVelocityX(this.pipeSpeed);
        topPipe.setImmovable(true);
        topPipe.scored = false;
        topPipe.isTopPipe = true;

        // Bottom pipe
        const bottomPipe = this.pipes.create(
            this.game.config.width,
            gapY + gapSize / 2,
            'pipe-green'
        );
        bottomPipe.setOrigin(0.5, 0);
        bottomPipe.body.allowGravity = false;
        bottomPipe.body.setVelocityX(this.pipeSpeed);
        bottomPipe.setImmovable(true);
        bottomPipe.scored = false;
    }

    pipeCollision() {
        if (!this.gameOver) {
            this.isGameOver();
        }
    }

    groundCollision() {
        if (!this.gameOver) {
            this.isGameOver();
        }
    }

    isGameOver() {
        this.gameOver = true;

        // Use player die method
        this.player.die();
        this.player.stop();

        // Pause physics
        this.physics.pause();

        // Stop pipe spawning
        if (this.pipeTimer) {
            this.pipeTimer.destroy();
        }

        // Display Game Over text
        this.add.text(
            this.game.config.width / 2,
            this.game.config.height / 2 - 50,
            'Game Over!',
            {
                fontSize: '48px',
                fill: '#fff',
                fontFamily: 'Arial',
                stroke: '#000',
                strokeThickness: 8
            }
        ).setOrigin(0.5);

        this.add.text(
            this.game.config.width / 2,
            this.game.config.height / 2 + 30,
            `Score: ${this.score}`,
            {
                fontSize: '24px',
                fill: '#fff',
                fontFamily: 'Arial',
                stroke: '#000',
                strokeThickness: 6
            }
        ).setOrigin(0.5);

        this.add.text(
            this.game.config.width / 2,
            this.game.config.height / 2 + 70,
            'Click or Press SPACE to Restart',
            {
                fontSize: '16px',
                fill: '#fff',
                fontFamily: 'Arial',
                stroke: '#000',
                strokeThickness: 4
            }
        ).setOrigin(0.5);

        // Allow restart
        this.time.delayedCall(500, () => {
            this.input.once('pointerdown', this.restartGame, this);
            this.input.keyboard.once('keydown-SPACE', this.restartGame, this);
        });
    }

    restartGame() {
        this.scene.restart();
        this.score = 0;
        this.gameOver = false;
    }

    update() {
        if (this.gameOver) return;

        // Update player
        this.player.update();

        // Scroll background
        this.background.tilePositionX += this.backgroundSpeed;

        // Scroll ground
        this.ground.tilePositionX += this.groundSpeed;

        // Check if player died from boundaries
        if (this.player.getIsDead()) {
            this.isGameOver();
        }

        // Clean up and score pipes
        this.pipes.children.entries.forEach(pipe => {
            if (pipe.x < -100) {
                pipe.destroy();
            }

            if (pipe.isTopPipe && !pipe.scored && pipe.x + pipe.width / 2 < this.player.getX()) {
                this.score++;
                this.scoreText.setText(this.score.toString());
                pipe.scored = true;
            }
        });
    }
}

class WorldScene extends Phaser.Scene {
    constructor() {
        super({ key: 'worldScene' });

        // Speed settings for scrolling
        this.backgroundSpeed = 1;
        this.groundSpeed = 2;
    }

    preload() {
        // Load background image
        this.load.image('background-day', 'sprites/background-day.png');

        // Load ground image
        this.load.image('ground', 'sprites/base.png');
    }

    create() {
        // Create the moving background
        this.createBackground();

        // Create the moving ground
        this.createGround();
    }

    createBackground() {
        // tileSprite allows us to create a repeating, scrollable texture
        // Parameters: (x, y, width, height, texture key)
        this.background = this.add.tileSprite(
            0,                              // x position (top-left corner)
            0,                              // y position (top-left corner)
            this.game.config.width * 2,     // width (make it 2x screen width for seamless scrolling)
            this.game.config.height,        // height (full screen height)
            'background-day'                // texture to use
        );
        
        // Set origin to top-left corner
        this.background.setOrigin(0, 0);
        
        // Prevent camera from moving this object
        this.background.setScrollFactor(0);
    }

    createGround() {
        // Position ground at the bottom of the screen
        const groundY = this.game.config.height - 56;  // 56 pixels from bottom
        
        // Create scrolling ground
        this.ground = this.add.tileSprite(
            0,                              // x position
            groundY,                        // y position (near bottom)
            this.game.config.width * 2,     // width
            112,                            // height of ground sprite
            'ground'                        // texture
        );
        
        // Set origin to top-left
        this.ground.setOrigin(0, 0);
    }

    update() {
        // This runs every frame (about 60 times per second)
        
        // Scroll the background by increasing its tile position
        // This creates the illusion of movement
        this.background.tilePositionX += this.backgroundSpeed;

        // Scroll the ground faster for parallax effect
        // Objects closer to the camera move faster
        this.ground.tilePositionX += this.groundSpeed;
    }
}
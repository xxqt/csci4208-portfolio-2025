const config = {
    type  Phaser.AUTO,
    width: 
}
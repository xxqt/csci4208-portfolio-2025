// class WorldScene extends Phaser.Scene {
//     constructor() {
//         super({ key: 'worldScene' });

//         // Speed settings for scrolling
//         this.backgroundSpeed = 1;
//         this.groundSpeed = 2;
//         this.pipeSpeed = 2;
//         this.pipeGap = 150; // Gap between top and bottom pipes
//         this.pipeSpacing = 300; // Horizontal spacing between pipe pairs
//     }

//     preload() {
//         // numbers
//         this.load.image('0', 'sprites/0.png');
//         this.load.image('1', 'sprites/1.png');
//         this.load.image('2', 'sprites/2.png');
//         this.load.image('3', 'sprites/3.png');
//         this.load.image('4', 'sprites/4.png');
//         this.load.image('5', 'sprites/5.png');
//         this.load.image('6', 'sprites/6.png');
//         this.load.image('7', 'sprites/7.png');
//         this.load.image('8', 'sprites/8.png');
//         this.load.image('9', 'sprites/9.png');

//         // backgrounds
//         this.load.image('background-day', 'sprites/background-day.png');
//         this.load.image('background-night', 'sprites/background-night.png');

//         // pipes
//         this.load.image('pipe-green', 'sprites/pipe-green.png');

//         // ground
//         this.load.image('ground', 'sprites/base.png');

//         // flappy bird
//         this.load.image('yellowbird-upflap', 'sprites/yellowbird-upflap.png');
//         this.load.image('yellowbird-midflap', 'sprites/yellowbird-midflap.png');
//         this.load.image('yellowbird-downflap', 'sprites/yellowbird-downflap.png');
//     }

//     create() {
//         // Create the moving background
//         this.createBackground();

//         // Create pipes group
//         this.createPipes();

//         // Start spawning pipes
//         this.startPipeSpawner();

//         // Create the moving ground LAST so it renders on top
//         this.createGround();
//     }

//     createBackground() {
//         // tileSprite allows us to create a repeating, scrollable texture
//         // Parameters: (x, y, width, height, texture key)
//         this.background = this.add.tileSprite(
//             0,                              // x position (top-left corner)
//             0,                              // y position (top-left corner)
//             this.game.config.width * 2,     // width (make it 2x screen width for seamless scrolling)
//             this.game.config.height,        // height (full screen height)
//             'background-day'                // texture to use
//         );
        
//         // Set origin to top-left corner
//         this.background.setOrigin(0, 0);
        
//         // Prevent camera from moving this object
//         this.background.setScrollFactor(0);
//     }

//     createGround() {
//         // Position ground at the bottom of the screen
//         const groundY = this.game.config.height - 56;  // 56 pixels from bottom
        
//         // Create scrolling ground
//         this.ground = this.add.tileSprite(
//             0,                              // x position
//             groundY,                        // y position (near bottom)
//             this.game.config.width * 2,     // width
//             112,                            // height of ground sprite
//             'ground'                        // texture
//         );
        
//         // Set origin to top-left
//         this.ground.setOrigin(0, 0);
        
//         // Set depth higher than pipes so ground always renders on top
//         this.ground.setDepth(100);
//     }

//     createPipes() {
//         // Create a group to hold all pipes
//         this.pipes = this.add.group();
        
//         // Track the rightmost pipe position
//         this.lastPipeX = this.game.config.width;
//     }

//     startPipeSpawner() {
//         // Spawn first set of pipes
//         this.spawnPipe();
        
//         // Set up timer to spawn pipes at regular intervals
//         this.pipeTimer = this.time.addEvent({
//             delay: 2000, // Spawn a new pipe pair every 2 seconds
//             callback: this.spawnPipe,
//             callbackScope: this,
//             loop: true
//         });
//     }

//     spawnPipe() {
//         // Calculate a random gap position
//         const minGapY = 100;
//         const maxGapY = this.game.config.height - 112 - 100 - this.pipeGap;
//         const gapY = Phaser.Math.Between(minGapY, maxGapY);
        
//         // Create top pipe
//         const topPipe = this.add.image(
//             this.game.config.width + 50,
//             gapY,
//             'pipe-green'
//         );
//         topPipe.setOrigin(0.5, 1); // Bottom-center anchor
//         topPipe.setFlipY(true); // Flip vertically for top pipe
//         topPipe.setDepth(0); // Ensure pipes stay behind ground
        
//         // Create bottom pipe
//         const bottomPipe = this.add.image(
//             this.game.config.width + 50,
//             gapY + this.pipeGap,
//             'pipe-green'
//         );
//         bottomPipe.setOrigin(0.5, 0); // Top-center anchor
//         bottomPipe.setDepth(0); // Ensure pipes stay behind ground
        
//         // Add both pipes to the group
//         this.pipes.add(topPipe);
//         this.pipes.add(bottomPipe);
        
//         // Store data for scoring
//         topPipe.setData('scored', false);
//         bottomPipe.setData('scored', false);
//     }

//     update() {
//         // This runs every frame (about 60 times per second)
        
//         // Scroll the background by increasing its tile position
//         // This creates the illusion of movement
//         this.background.tilePositionX += this.backgroundSpeed;

//         // Scroll the ground faster for parallax effect
//         // Objects closer to the camera move faster
//         this.ground.tilePositionX += this.groundSpeed;

//         // Move pipes
//         this.movePipes();
//     }

//     movePipes() {
//         // Move each pipe to the left
//         this.pipes.getChildren().forEach(pipe => {
//             pipe.x -= this.pipeSpeed;
            
//             // Remove pipes that have moved off screen
//             if (pipe.x < -50) {
//                 pipe.destroy();
//             }
//         });
//     }
// }

class WorldScene extends Phaser.Scene {
    constructor() {
        super({ key: 'worldScene' });

        // Speed settings for scrolling
        this.backgroundSpeed = 1;
        this.groundSpeed = 2;
        this.pipeSpeed = 2;
        this.pipeGap = 150; // Gap between top and bottom pipes
        this.pipeSpacing = 300; // Horizontal spacing between pipe pairs
    }

    preload() {
        // numbers
        this.load.image('0', 'sprites/0.png');
        this.load.image('1', 'sprites/1.png');
        this.load.image('2', 'sprites/2.png');
        this.load.image('3', 'sprites/3.png');
        this.load.image('4', 'sprites/4.png');
        this.load.image('5', 'sprites/5.png');
        this.load.image('6', 'sprites/6.png');
        this.load.image('7', 'sprites/7.png');
        this.load.image('8', 'sprites/8.png');
        this.load.image('9', 'sprites/9.png');

        // backgrounds
        this.load.image('background-day', 'sprites/background-day.png');
        this.load.image('background-night', 'sprites/background-night.png');

        // pipes
        this.load.image('pipe-green', 'sprites/pipe-green.png');

        // ground
        this.load.image('ground', 'sprites/base.png');

        // flappy bird
        this.load.image('yellowbird-upflap', 'sprites/yellowbird-upflap.png');
        this.load.image('yellowbird-midflap', 'sprites/yellowbird-midflap.png');
        this.load.image('yellowbird-downflap', 'sprites/yellowbird-downflap.png');
    }

    create() {
        // Create the moving background
        this.createBackground();

        // Create pipes group
        this.createPipes();

        // Start spawning pipes
        this.startPipeSpawner();

        // Create the moving ground LAST so it renders on top
        this.createGround();

        // Create the player (bird)
        this.player = new Player(this, 100, this.game.config.height / 2);

        // Set up input for flapping
        this.input.on('pointerdown', () => {
            this.player.flap();
        });

        // Also allow spacebar for flapping
        this.cursors = this.input.keyboard.createCursorKeys();
        this.spaceKey = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.SPACE);
    }

    createBackground() {
        // tileSprite allows us to create a repeating, scrollable texture
        // Parameters: (x, y, width, height, texture key)
        this.background = this.add.tileSprite(
            0,                              // x position (top-left corner)
            0,                              // y position (top-left corner)
            this.game.config.width * 2,     // width (make it 2x screen width for seamless scrolling)
            this.game.config.height,        // height (full screen height)
            'background-day'                // texture to use
        );
        
        // Set origin to top-left corner
        this.background.setOrigin(0, 0);
        
        // Prevent camera from moving this object
        this.background.setScrollFactor(0);
    }

    createGround() {
        // Position ground at the bottom of the screen
        const groundY = this.game.config.height - 56;  // 56 pixels from bottom
        
        // Create scrolling ground
        this.ground = this.add.tileSprite(
            0,                              // x position
            groundY,                        // y position (near bottom)
            this.game.config.width * 2,     // width
            112,                            // height of ground sprite
            'ground'                        // texture
        );
        
        // Set origin to top-left
        this.ground.setOrigin(0, 0);
        
        // Set depth higher than pipes so ground always renders on top
        this.ground.setDepth(100);
    }

    createPipes() {
        // Create a group to hold all pipes
        this.pipes = this.add.group();
        
        // Track the rightmost pipe position
        this.lastPipeX = this.game.config.width;
    }

    startPipeSpawner() {
        // Spawn first set of pipes
        this.spawnPipe();
        
        // Set up timer to spawn pipes at regular intervals
        this.pipeTimer = this.time.addEvent({
            delay: 2000, // Spawn a new pipe pair every 2 seconds
            callback: this.spawnPipe,
            callbackScope: this,
            loop: true
        });
    }

    spawnPipe() {
        // Calculate a random gap position
        const minGapY = 100;
        const maxGapY = this.game.config.height - 112 - 100 - this.pipeGap;
        const gapY = Phaser.Math.Between(minGapY, maxGapY);
        
        // Create top pipe
        const topPipe = this.add.image(
            this.game.config.width + 50,
            gapY,
            'pipe-green'
        );
        topPipe.setOrigin(0.5, 1); // Bottom-center anchor
        topPipe.setFlipY(true); // Flip vertically for top pipe
        topPipe.setDepth(0); // Ensure pipes stay behind ground
        
        // Create bottom pipe
        const bottomPipe = this.add.image(
            this.game.config.width + 50,
            gapY + this.pipeGap,
            'pipe-green'
        );
        bottomPipe.setOrigin(0.5, 0); // Top-center anchor
        bottomPipe.setDepth(0); // Ensure pipes stay behind ground
        
        // Add both pipes to the group
        this.pipes.add(topPipe);
        this.pipes.add(bottomPipe);
        
        // Store data for scoring
        topPipe.setData('scored', false);
        bottomPipe.setData('scored', false);
    }

    update() {
        // This runs every frame (about 60 times per second)
        
        // Scroll the background by increasing its tile position
        // This creates the illusion of movement
        this.background.tilePositionX += this.backgroundSpeed;

        // Scroll the ground faster for parallax effect
        // Objects closer to the camera move faster
        this.ground.tilePositionX += this.groundSpeed;

        // Move pipes
        this.movePipes();

        // Update player
        if (this.player) {
            this.player.update();

            // Check for spacebar press
            if (Phaser.Input.Keyboard.JustDown(this.spaceKey)) {
                this.player.flap();
            }
        }
    }

    movePipes() {
        // Move each pipe to the left
        this.pipes.getChildren().forEach(pipe => {
            pipe.x -= this.pipeSpeed;
            
            // Remove pipes that have moved off screen
            if (pipe.x < -50) {
                pipe.destroy();
            }
        });
    }
}
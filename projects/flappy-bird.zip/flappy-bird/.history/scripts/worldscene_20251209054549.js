class WorldScene extends Phaser.Scene {
    constructor() {
        super({ key: 'worldscene' });
    }

    preload() {
        // numbers
        this.load.image('0', '/0.png');

    }

    create() {

    }

    update() {

    }
}

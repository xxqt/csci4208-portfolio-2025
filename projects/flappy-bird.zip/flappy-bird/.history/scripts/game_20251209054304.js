const config = {
    type  Phaser.AUTO,
    width: 288,
    height: 512,
    physics: {}
}
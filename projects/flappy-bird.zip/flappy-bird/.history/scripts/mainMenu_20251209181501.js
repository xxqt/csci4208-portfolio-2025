class mainMenu extends Phaser.Scene {
    constructor() {
        super({ key: 'mainMenu' });
    }
    preload() {
        this.load.image('menu-bg', 'sprites/message.png');
        this.load.image('background', 'sprites/background-day.png');    
        this.load.image('ground', 'sprites/ground.png');

    }
    create() {
        this.add.image(288, 512, 'background');
        this.add.image(184, 267, 'menu-bg');

        this.spaceKey = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.SPACE);
    }

    update() {
}
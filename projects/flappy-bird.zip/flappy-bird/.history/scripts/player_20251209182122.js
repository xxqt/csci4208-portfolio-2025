class Player {
    constructor(scene, x, y) {
        this.scene = scene;
        
        // Create the bird sprite
        this.sprite = scene.physics.add.sprite(x, y, 'yellowbird-midflap');
        this.sprite.setScale(2);
        this.sprite.setCollideWorldBounds(false);
        
        // Set gravity for the bird
        this.sprite.body.setGravityY(700);
        
        // Flap properties
        this.flapPower = -400;
        this.isDead = false;
        
        // Rotation properties
        this.maxUpAngle = -20;
        this.maxDownAngle = 90;
        this.rotationSpeed = 3;
        
        // Create and play animation
        this.createAnimations();
        this.sprite.play('fly');
    }
    
    createAnimations() {
        // Check if animation already exists to avoid duplicates
        if (!this.scene.anims.exists('fly')) {
            this.scene.anims.create({
                key: 'fly',
                frames: [
                    { key: 'yellowbird-upflap' },
                    { key: 'yellowbird-midflap' },
                    { key: 'yellowbird-downflap' }
                ],
                frameRate: 10,
                repeat: -1
            });
        }
    }
    
    flap() {
        if (this.isDead) return;
        
        // Apply upward velocity
        this.sprite.setVelocityY(this.flapPower);
        
        // Rotate bird upward
        this.scene.tweens.add({
            targets: this.sprite,
            angle: this.maxUpAngle,
            duration: 100,
            ease: 'Linear'
        });
    }
    
    update() {
        if (this.isDead) return;
        
        // Rotate bird down when falling
        if (this.sprite.body.velocity.y > 0) {
            if (this.sprite.angle < this.maxDownAngle) {
                this.sprite.angle += this.rotationSpeed;
            }
        }
        
        // Check if bird is out of bounds (top or bottom)
        if (this.sprite.y < 0 || this.sprite.y > this.scene.game.config.height) {
            this.die();
        }
    }
    
    die() {
        if (this.isDead) return;
        
        this.isDead = true;
        
        // Stop animation
        this.sprite.anims.stop();
        
        // Change color to red
        this.sprite.setTint(0xff0000);
        
        // Optional: Add death animation
        this.scene.tweens.add({
            targets: this.sprite,
            angle: 90,
            duration: 200,
            ease: 'Linear'
        });
    }
    
    reset(x, y) {
        // Reset player state
        this.isDead = false;
        this.sprite.clearTint();
        this.sprite.setPosition(x, y);
        this.sprite.setVelocity(0, 0);
        this.sprite.setAngle(0);
        this.sprite.play('fly');
    }
    
    // Getters for collision detection
    getSprite() {
        return this.sprite;
    }
    
    getX() {
        return this.sprite.x;
    }
    
    getY() {
        return this.sprite.y;
    }
    
    getIsDead() {
        return this.isDead;
    }
    
    // Stop the bird (for game over)
    stop() {
        this.sprite.setVelocity(0, 0);
        this.sprite.anims.stop();
    }
}
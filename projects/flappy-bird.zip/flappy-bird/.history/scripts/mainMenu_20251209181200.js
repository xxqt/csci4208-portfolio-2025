class mainMenu extends Phaser.Scene {
    constructor() {
        super({ key: 'mainMenu' });
    }
    preload() {
        this.load.image('menu-bg', 'sprites/message.png');
        this.load.image('background', 'sprites/background-day.png');    
        this.load.image('ground', 'sprites/ground.png');

    }
    create() {
        this.add.image(144, 256, 'menu-bg');
    }
}
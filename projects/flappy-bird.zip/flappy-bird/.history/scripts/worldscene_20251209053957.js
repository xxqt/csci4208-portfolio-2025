class worldscene extends Phaser.Scene {
    constructor() {
        super({ key: 'worldscene' });
    }

    preload() {

    }

    create() {}
const Skip = () => (                                                  //Function for HTML component       
   `<div> 
       <button onclick='playGame()'> Skip </button> 
   </div>` 
) 
 
export default Skip;                                                    //Export Skip function 